﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleChart
{
    class Data
    {
        string Country;
        string TimeOfDay;
        string Animal;
        int Attacks;

        public Data(string Country, string TimeOfDay, string Animal, int Attacks)
        {
            this.Country = Country;
            this.TimeOfDay = TimeOfDay;
            this.Animal = Animal;
            this.Attacks = Attacks;
        }
        
    
        public void setAttacks(int attacks)
        {
            Attacks = attacks;
        }
        public int getAttacks()
        {
            return Attacks;
        }

        public void setCountry(string country)
        {
            Country = country;
        }
        public string getCountry()
        {
            return Country;
        }

        public void setTimeOfDay(string time)
        {
            TimeOfDay = time;
        }
        public string getTimeOfDay()
        {
            return TimeOfDay;
        }

        public void setAnimal(string animal)
        {
            Animal = animal;
        }
        public string getAnimal()
        {
            return Animal;
        }
    }
}
