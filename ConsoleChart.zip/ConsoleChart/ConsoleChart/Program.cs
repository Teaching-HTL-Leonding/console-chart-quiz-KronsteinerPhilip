﻿using ConsoleChart;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;



/// <summary>
/// Nach stundenlangem Kopfzerbrechen mit maßgeblicher Hilfe von Markus Steininger gelöst.
/// </summary>

Dictionary<string, int> dict = new Dictionary<string, int>();

string[] columns = Console.ReadLine().Split('\t');
int groupColumn = Array.IndexOf(columns, args[0]);
int valueColumn = Array.IndexOf(columns, args[1]);
int numberOfLines = Convert.ToInt32(args[2]);

string line;
while ((line = Console.ReadLine()) != null)
{
    columns = line.Split('\t');
    string group = columns[groupColumn];
    int value = int.Parse(columns[valueColumn]);

    if (dict.Keys.Contains(group))
        dict[group] += value;
    else
        dict.Add(group, value);
}



dict = dict.OrderByDescending(v => v.Value).ToDictionary(v => v.Key, v => v.Value);

int maxValue = dict.Values.Max();

for (int i = 0; i < numberOfLines; i++)
{
    Console.Write("{0,40}| ", dict.ElementAt(i).Key);
    Console.BackgroundColor = ConsoleColor.Cyan;
    Console.Write(new string(' ', (int)Math.Ceiling(dict.ElementAt(i).Value * 100.0 / maxValue)));
    Console.BackgroundColor = ConsoleColor.Black;
    Console.WriteLine("");
}